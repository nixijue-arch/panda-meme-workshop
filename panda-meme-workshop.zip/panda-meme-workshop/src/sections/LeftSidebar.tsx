import { useState } from 'react';
import { useMeme } from '@/context/MemeContext';
import { useIsMobile } from '@/hooks/useMediaQuery';
import { PANDA_HEADS, FACES, getPandaFaceOffset } from '@/data/materials';
import type { ImageElement, MemeElement } from '@/context/MemeContext';
import { X } from 'lucide-react';

function isElementActive(elements: MemeElement[], itemId: string): boolean {
  return elements.some(e => e.type === 'image' && (e as ImageElement).name === itemId);
}

function isPanda(e: MemeElement): boolean {
  if (e.type !== 'image') return false;
  const name = (e as ImageElement).name;
  return PANDA_HEADS.some(p => p.id === name) || name.startsWith('upload-panda-');
}

function isFace(e: MemeElement): boolean {
  if (e.type !== 'image') return false;
  const name = (e as ImageElement).name;
  return FACES.some(f => f.id === name) || name.startsWith('upload-face-');
}

export function LeftSidebar() {
  const { state, dispatch, generateId } = useMeme();
  const isMobile = useIsMobile();
  const [sheetOpen, setSheetOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'panda' | 'face'>('panda');

  const handleAddPandaHead = (src: string, id: string) => {
    state.elements.filter(isPanda).forEach(e => {
      dispatch({ type: 'REMOVE_ELEMENT', id: e.id });
    });
    setTimeout(() => {
      const element: ImageElement = {
        id: generateId(), type: 'image', src, name: id,
        x: 75, y: 50, width: 350, height: 350,
        rotation: 0, opacity: 1, zIndex: 0, flipX: false,
      };
      dispatch({ type: 'ADD_ELEMENT', element });
    }, 0);
    if (isMobile) setSheetOpen(false);
  };

  const handleAddFace = (src: string, id: string) => {
    state.elements.filter(isFace).forEach(e => {
      dispatch({ type: 'REMOVE_ELEMENT', id: e.id });
    });
    const currentPanda = state.elements.find(isPanda) as ImageElement | undefined;
    if (!currentPanda) {
      const pandaElement: ImageElement = {
        id: generateId(), type: 'image', src: '/assets/panda-head.png', name: 'panda-head',
        x: 75, y: 50, width: 350, height: 350,
        rotation: 0, opacity: 1, zIndex: 0, flipX: false,
      };
      dispatch({ type: 'ADD_ELEMENT', element: pandaElement });
    }
    const pandaId = currentPanda?.name ?? 'panda-head';
    const offset = getPandaFaceOffset(pandaId);
    setTimeout(() => {
      const faceElement: ImageElement = {
        id: generateId(), type: 'image', src, name: id,
        x: offset.x, y: offset.y, width: offset.w, height: offset.h,
        rotation: 0, opacity: 1, zIndex: 1, flipX: false,
      };
      dispatch({ type: 'ADD_ELEMENT', element: faceElement });
    }, 10);
    if (isMobile) setSheetOpen(false);
  };

  // ===== MOBILE: Bottom Sheet =====
  if (isMobile) {
    // In museum edit mode, hide the material FAB entirely
    if (state.museumEditMode) {
      return null;
    }

    const title = state.language === 'zh' ? '选择素材' : 'Choose Materials';
    const pandaTabLabel = state.language === 'zh' ? '熊猫头' : 'Panda';
    const faceTabLabel = state.language === 'zh' ? '人脸' : 'Face';

    return (
      <>
        {/* FAB */}
        <button
          className="mobile-fab-left"
          onClick={() => setSheetOpen(true)}
          title={title}
        >
          🐼
        </button>

        {/* Overlay */}
        <div className={`bottom-sheet-overlay ${sheetOpen ? 'open' : ''}`} onClick={() => setSheetOpen(false)} />

        {/* Sheet */}
        <div className={`bottom-sheet ${sheetOpen ? 'open' : ''}`}>
          <div className="bottom-sheet-header">
            <span className="bottom-sheet-title">{title}</span>
            <button className="bottom-sheet-close" onClick={() => setSheetOpen(false)}>
              <X size={18} />
            </button>
          </div>

          {/* Tabs */}
          <div style={{ display: 'flex', borderBottom: '1px solid #2a2a2a' }}>
            <button
              onClick={() => setActiveTab('panda')}
              className="flex-1 py-3 text-sm font-medium transition-all"
              style={{
                backgroundColor: activeTab === 'panda' ? 'rgba(255,94,0,0.1)' : 'transparent',
                color: activeTab === 'panda' ? '#FF5E00' : '#888',
                borderBottom: activeTab === 'panda' ? '2px solid #FF5E00' : '2px solid transparent',
              }}
            >
              {pandaTabLabel}
            </button>
            <button
              onClick={() => setActiveTab('face')}
              className="flex-1 py-3 text-sm font-medium transition-all"
              style={{
                backgroundColor: activeTab === 'face' ? 'rgba(255,94,0,0.1)' : 'transparent',
                color: activeTab === 'face' ? '#FF5E00' : '#888',
                borderBottom: activeTab === 'face' ? '2px solid #FF5E00' : '2px solid transparent',
              }}
            >
              {faceTabLabel}
            </button>
          </div>

          <div className="bottom-sheet-body">
            {activeTab === 'panda' && (
              <div className="grid grid-cols-3 gap-3">
                {PANDA_HEADS.map(item => (
                  <button
                    key={item.id}
                    onClick={() => handleAddPandaHead(item.src, item.id)}
                    className="flex flex-col items-center gap-1 p-2 rounded-lg transition-all active:scale-95"
                    style={{
                      backgroundColor: '#FFFFFF',
                      border: isElementActive(state.elements, item.id) ? '2px solid #FF5E00' : '1px solid #ddd',
                    }}
                  >
                    <img src={item.src} alt={state.language === 'zh' ? item.labelCn : item.labelEn}
                      className="w-full h-16 object-contain" draggable={false} loading="lazy" />
                    <span className="text-[10px] truncate w-full text-center" style={{ color: '#666' }}>
                      {state.language === 'zh' ? item.labelCn : item.labelEn}
                    </span>
                  </button>
                ))}
              </div>
            )}
            {activeTab === 'face' && (
              <div className="grid grid-cols-3 gap-3">
                {FACES.map(item => (
                  <button
                    key={item.id}
                    onClick={() => handleAddFace(item.src, item.id)}
                    className="flex flex-col items-center gap-1 p-2 rounded-lg transition-all active:scale-95"
                    style={{
                      backgroundColor: '#FFFFFF',
                      border: isElementActive(state.elements, item.id) ? '2px solid #FF5E00' : '1px solid #ddd',
                    }}
                  >
                    <img src={item.src} alt={state.language === 'zh' ? item.labelCn : item.labelEn}
                      className="w-full h-16 object-contain" draggable={false} loading="lazy" />
                    <span className="text-[10px] truncate w-full text-center" style={{ color: '#666' }}>
                      {state.language === 'zh' ? item.labelCn : item.labelEn}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </>
    );
  }

  // ===== DESKTOP: Side Panel =====
  // In museum edit mode, show a locked message instead of material grid
  if (state.museumEditMode) {
    return (
      <aside className="desktop-sidebar-left" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '12px' }}>
        <div className="text-3xl">🔒</div>
        <p className="text-xs text-center" style={{ color: '#888' }}>
          {state.language === 'zh'
            ? '博物馆编辑模式\n仅支持文字编辑'
            : 'Museum edit mode\nText editing only'}
        </p>
      </aside>
    );
  }

  return (
    <aside className="desktop-sidebar-left">
      <div className="sidebar-section sidebar-panda">
        <div className="sidebar-section-header">
          <span className="sidebar-icon">🐼</span>
          <span className="sidebar-label">
            {state.language === 'zh' ? '选择熊猫头' : 'Choose Panda Head'}
          </span>
        </div>
        <div className="sidebar-scroll">
          <div className="sidebar-grid">
            {PANDA_HEADS.map(item => (
              <MaterialCard
                key={item.id}
                item={item}
                active={isElementActive(state.elements, item.id)}
                onClick={() => handleAddPandaHead(item.src, item.id)}
              />
            ))}
          </div>
        </div>
      </div>

      <div className="sidebar-section sidebar-face">
        <div className="sidebar-section-header">
          <span className="sidebar-icon">😂</span>
          <span className="sidebar-label">
            {state.language === 'zh' ? '选择人脸' : 'Choose Face'}
          </span>
        </div>
        <div className="sidebar-scroll">
          <div className="sidebar-grid">
            {FACES.map(item => (
              <MaterialCard
                key={item.id}
                item={item}
                active={isElementActive(state.elements, item.id)}
                onClick={() => handleAddFace(item.src, item.id)}
              />
            ))}
          </div>
        </div>
      </div>

      <div className="sidebar-hint">
        {state.language === 'zh' ? '点击素材 · 拖拽调整位置' : 'Click to add · Drag to position'}
      </div>
    </aside>
  );
}

function MaterialCard({ item, active, onClick }: {
  item: { id: string; src: string; labelCn: string; labelEn: string };
  active: boolean;
  onClick: () => void;
}) {
  const { state } = useMeme();

  return (
    <button
      onClick={onClick}
      className="material-card"
      style={{
        backgroundColor: '#FFFFFF',
        border: active ? '2px solid #FF5E00' : '1px solid #ddd',
        boxShadow: active ? '0 0 0 1px #FF5E00' : 'none',
      }}
      onMouseEnter={e => {
        e.currentTarget.style.borderColor = '#FF5E00';
        e.currentTarget.style.boxShadow = '0 2px 8px rgba(255,94,0,0.2)';
      }}
      onMouseLeave={e => {
        if (!active) {
          e.currentTarget.style.borderColor = '#ddd';
          e.currentTarget.style.boxShadow = 'none';
        } else {
          e.currentTarget.style.borderColor = '#FF5E00';
          e.currentTarget.style.boxShadow = '0 0 0 1px #FF5E00';
        }
      }}
    >
      <img
        src={item.src}
        alt={state.language === 'zh' ? item.labelCn : item.labelEn}
        className="material-img"
        draggable={false}
        loading="lazy"
      />
      <span className="material-label">
        {state.language === 'zh' ? item.labelCn : item.labelEn}
      </span>
    </button>
  );
}
