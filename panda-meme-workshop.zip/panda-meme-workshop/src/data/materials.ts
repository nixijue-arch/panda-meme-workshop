export interface PandaHeadItem {
  id: string;
  src: string;
  labelCn: string;
  labelEn: string;
  /** Face placement config: where to overlay the face on this panda body */
  faceOffset: { x: number; y: number; w: number; h: number };
}

export interface FaceItem {
  id: string;
  src: string;
  labelCn: string;
  labelEn: string;
}

// 11 panda head templates (from user's uploaded images)
// faceOffset tuned so the face lands exactly on the eyes of each body pose
export const PANDA_HEADS: PandaHeadItem[] = [
  { id: 'panda-head',    src: '/assets/panda-head.png',    labelCn: '空白', labelEn: 'Blank',    faceOffset: { x: 160, y: 90, w: 180, h: 180 } },
  { id: 'panda-salute',  src: '/assets/panda-salute.png',  labelCn: '敬礼', labelEn: 'Salute',   faceOffset: { x: 160, y: 82, w: 180, h: 180 } },
  { id: 'panda-stand',   src: '/assets/panda-stand.png',   labelCn: '站立', labelEn: 'Stand',    faceOffset: { x: 160, y: 85, w: 180, h: 180 } },
  { id: 'panda-lie',     src: '/assets/panda-lie.png',     labelCn: '躺平', labelEn: 'Lie Down', faceOffset: { x: 160, y: 105, w: 180, h: 180 } },
  { id: 'panda-crossarm',src: '/assets/panda-crossarm.png',labelCn: '抱臂', labelEn: 'Cross Arm',faceOffset: { x: 160, y: 88, w: 180, h: 180 } },
  { id: 'panda-side',    src: '/assets/panda-side.png',    labelCn: '侧身', labelEn: 'Side',     faceOffset: { x: 168, y: 88, w: 175, h: 175 } },
  { id: 'panda-railing', src: '/assets/panda-railing.png', labelCn: '栏杆', labelEn: 'Railing',  faceOffset: { x: 160, y: 80, w: 180, h: 180 } },
  { id: 'panda-plane',   src: '/assets/panda-plane.png',   labelCn: '起飞', labelEn: 'Takeoff',  faceOffset: { x: 160, y: 85, w: 180, h: 180 } },
  { id: 'panda-lean',    src: '/assets/panda-lean.png',    labelCn: '倚靠', labelEn: 'Lean',     faceOffset: { x: 168, y: 88, w: 175, h: 175 } },
  { id: 'panda-hand',    src: '/assets/panda-hand.png',    labelCn: '举手', labelEn: 'Hand Up',  faceOffset: { x: 160, y: 85, w: 180, h: 180 } },
  { id: 'panda-question',src: '/assets/panda-question.png',labelCn: '疑问', labelEn: 'Question', faceOffset: { x: 160, y: 88, w: 180, h: 180 } },
];

// Helper: find the face offset for a given panda id
export function getPandaFaceOffset(pandaId: string) {
  const panda = PANDA_HEADS.find(p => p.id === pandaId);
  return panda?.faceOffset ?? { x: 160, y: 90, w: 180, h: 180 };
}

// 15 face overlays (from user's uploaded images)
export const FACES: FaceItem[] = [
  { id: 'face-01', src: '/assets/face-01.png', labelCn: '惊讶', labelEn: 'Surprised' },
  { id: 'face-02', src: '/assets/face-02.png', labelCn: '奸笑', labelEn: 'Grin' },
  { id: 'face-03', src: '/assets/face-03.png', labelCn: '红脸', labelEn: 'Blush' },
  { id: 'face-04', src: '/assets/face-04.png', labelCn: '呆脸', labelEn: 'Dazed' },
  { id: 'face-05', src: '/assets/face-05.png', labelCn: '哭泣', labelEn: 'Crying' },
  { id: 'face-06', src: '/assets/face-06.png', labelCn: '墨镜', labelEn: 'Cool' },
  { id: 'face-07', src: '/assets/face-07.png', labelCn: '挑衅', labelEn: 'Smug' },
  { id: 'face-08', src: '/assets/face-08.png', labelCn: '咧嘴', labelEn: 'Big Grin' },
  { id: 'face-09', src: '/assets/face-09.png', labelCn: '皱眉', labelEn: 'Frown' },
  { id: 'face-10', src: '/assets/face-10.png', labelCn: '大笑', labelEn: 'Laughing' },
  { id: 'face-11', src: '/assets/face-11.png', labelCn: '挑眉', labelEn: 'Eyebrow' },
  { id: 'face-12', src: '/assets/face-12.png', labelCn: '眼泪', labelEn: 'Tears' },
  { id: 'face-13', src: '/assets/face-13.png', labelCn: '阴险', labelEn: 'Sinister' },
  { id: 'face-14', src: '/assets/face-14.png', labelCn: '狗头', labelEn: 'Doggo' },
  { id: 'face-15', src: '/assets/face-15.png', labelCn: '痛苦', labelEn: 'Pain' },
];
